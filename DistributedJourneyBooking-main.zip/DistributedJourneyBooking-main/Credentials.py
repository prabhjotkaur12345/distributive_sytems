servers = [
    {
        "host": "mysql1",
        "user":"root",
        "password":"example",
        "database":"bdteste"
    },
    {
        "host": "mysql2",
        "user":"root",
        "password":"example",
        "database":"bdteste"
    }
]



